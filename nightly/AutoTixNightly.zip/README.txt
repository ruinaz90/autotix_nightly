# AutoTix Nightly
An application to automate nightly for the fulfillment team.

## Installation
Use the package manager to install AutoTix Nightly.

## Instructions
1. Pull a sales report on CMS and export it as a CSV. Save this file to the Downloads folder.
2. Click the Run button in this app. A popup will appear when the app finishes running. Click OK. You can close the app
after this.
3. Go to the Nightly Check-in doc and click on the tab with today's date.
4. Paste the data in cell A1.

## Contribute
Send me your questions or comments.